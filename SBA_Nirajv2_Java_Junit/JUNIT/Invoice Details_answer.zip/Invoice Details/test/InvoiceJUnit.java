import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import static org.hamcrest.CoreMatchers.*;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.junit.Assert.assertThat;

public class InvoiceJUnit {

	InvoiceBO invoiceBO;
	List<Invoice> invoice;


	@Before
	public void createObjectForInvoiceBO() {
		// fill the code
		invoiceBO = new InvoiceBO();
	}

	@Test
	public void testFindInvoiceByAmount() throws InvalidAmountException {
		// fill the code
		
		Double amount = 85000.0;
		List<Invoice> invoice;

		invoice = invoiceBO.findInvoiceByAmount(amount);

		for(int i=0;i<invoice.size();i++) {
			System.out.format("%-5s %-15s %-17s %-15s %-10s %s\n",invoice.get(i).getId(),invoice.get(i).getCustomerName(),invoice.get(i).getPaymentAttempts(),invoice.get(i).getTotalAmount(),invoice.get(i).getBalance(),invoice.get(i).getStatus());
		}
		
		
List<Invoice> invoices = new ArrayList<Invoice>();
		

invoices.add(new Invoice(103,"James",6,85000.0,0.0,"Cleared"));

invoices.add(new Invoice(107,"John",6,85000.0,3000.0,"Pending"));

invoices.add(new Invoice(110,"David",3,85000.0,0.0,"Cleared"));

assertEquals(invoice, invoices);

	}

	@Test(expected = InvalidAmountException.class)
	public void testFindInvoiceByAmount_Exception() throws InvalidAmountException {
		// fill the code
		Double amount = -12.6;
		List<Invoice> invoice;

		invoice = invoiceBO.findInvoiceByAmount(amount);

	}

	@Test 
	public void testFindPendingInvoice() {
		// fill the code
		
		invoice = invoiceBO.findPendingInvoice();
		System.out.println(invoice.get(0).getCustomerName());
		

List<Invoice> invoices = new ArrayList<Invoice>();
		
		invoices.add(new Invoice(101,"Ricky",5,38000.0,4000.0,"Pending"));
		invoices.add(new Invoice(102,"Jack",4,74000.0,21000.0,"Pending"));
		invoices.add(new Invoice(104,"Peter",3,47000.0,8000.0,"Pending"));
		invoices.add(new Invoice(105,"Willium",8,68000.0,17000.0,"Pending"));
		invoices.add(new Invoice(107,"John",6,85000.0,3000.0,"Pending"));
		invoices.add(new Invoice(108,"Parker",3,47000.0,8000.0,"Pending"));
		invoices.add(new Invoice(109,"Augestine",8,68000.0,17000.0,"Pending"));
		
		assertEquals(invoice, invoices);

	}
}
