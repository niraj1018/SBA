import java.util.List;
import java.util.ArrayList;
public class InvoiceBO {
	
	
	public List<Invoice> findInvoiceByAmount(Double amount) throws InvalidAmountException {
		if(amount<0) {
			throw new InvalidAmountException("Amount is Invalid");
		}
		List<Invoice> invoices = new InvoiceDAO().loadInvoiceDetails();
		List<Invoice> amountInvoice = new ArrayList<Invoice>();
		
		for(int i=0;i<invoices.size();i++) {
			if(invoices.get(i).getTotalAmount().equals(amount)) {
				amountInvoice.add(invoices.get(i));
			}
		}
		
		return amountInvoice;
	}
	
	
	public List<Invoice> findPendingInvoice() {
		List<Invoice> invoices = new InvoiceDAO().loadInvoiceDetails();
		List<Invoice> pendingInvoice = new ArrayList<Invoice>();
		
		for(int i=0;i<invoices.size();i++) {
			if(invoices.get(i).getStatus().equalsIgnoreCase("pending")) {
				pendingInvoice.add(invoices.get(i));
			}
		}
		
		return pendingInvoice;
	}
	
	
}