import java.io.IOException;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.util.List;
public class Main {
	public static void main(String[] args) throws IOException {
		BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
		InvoiceBO invoiceBO = new InvoiceBO();
		System.out.println("Enter the amount to search :");
		Double amount = Double.parseDouble(buff.readLine());
		List<Invoice> invoice;
		try {
			invoice = invoiceBO.findInvoiceByAmount(amount);
			System.out.println("List of the Invoices more than $"+amount);
			System.out.format("%-5s %-15s %-17s %-15s %-10s %s\n","Id", "Customer Name","Payment Attempts","Total Amount","Balance","Status");
			for(int i=0;i<invoice.size();i++) {
				System.out.format("%-5s %-15s %-17s %-15s %-10s %s\n",invoice.get(i).getId(),invoice.get(i).getCustomerName(),invoice.get(i).getPaymentAttempts(),invoice.get(i).getTotalAmount(),invoice.get(i).getBalance(),invoice.get(i).getStatus());
			}
		}
		catch (InvalidAmountException e) {
			System.out.println(e);
		}
		invoice = invoiceBO.findPendingInvoice();
//		System.out.println("List of the Invoices which are pending for payment");
//		System.out.format("%-5s %-15s %-17s %-15s %-10s %s\n","Id", "Customer Name","Payment Attempts","Total Amount","Balance","Status");
		for(int i=0;i<invoice.size();i++) {
//			System.out.format("%-5s %-15s %-17s %-15s %-10s %s\n",invoice.get(i).getId(),invoice.get(i).getCustomerName(),invoice.get(i).getPaymentAttempts(),invoice.get(i).getTotalAmount(),invoice.get(i).getBalance(),invoice.get(i).getStatus());
		}
	}
}