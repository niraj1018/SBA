import java.io.BufferedReader;
//all needed package imports here

public class Main {
	
	//declare your enumerated data type for the cards here
	//declare the hash map here for card type to hours allowed mapping
	//Key MUST BE enumerated data type
	
	public static void main(String[] args)
	{	
	//load the hash map
		
	//Getting the input as card type from the user..	
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Welcome to TIA! Please enter the Card that you hold:");
	card = //complete this statement to read the user input
	//
		
	//case structure code goes here
	}
	
	}
}
