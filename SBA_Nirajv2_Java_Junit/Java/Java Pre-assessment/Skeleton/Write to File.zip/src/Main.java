import java.io.IOException;
// import needed package


public class Main {

//declare an array list

	static  proverbs = 
	
public static void main(String[] args) throws IOException  {

	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	System.out.println("Enter 3 proverbs to add");
	//Get 3 proverbs and store in Arraylist..
	String filename = 
	// write into a plain text (.txt) file named proverbs.txt. Each proverb should be a separate line.
	// MUST NOT contain any empty new line as the first or last line in the text file.
	
	
	
	
	System.out.println("proverbs has been added to the file!");
	
}
}

