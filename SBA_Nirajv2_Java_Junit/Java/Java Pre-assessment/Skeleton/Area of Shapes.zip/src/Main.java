class Shapes
{
	void area()
	{
		System.out.println("Displaying Area of different shapes");
	}
}

// Fill your code to display the formula for area of Circle and Square
class Circle		//Make other changes but DO NOT change name of the class
{

}

class Square		//Make other changes but DO NOT change name of the class
{

}

public class Main {
	public static void main(String args[])
	{
		//Call the method to print the formula for area of respective shapes using Runtime Polymorphism
	}
	
}
